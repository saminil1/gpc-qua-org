<?php
// 데이터베이스 접속
$conn = mysqli_connect('localhost', 'root', '111111');
mysqli_select_db($conn, 'opentutorials2');
 ?>
