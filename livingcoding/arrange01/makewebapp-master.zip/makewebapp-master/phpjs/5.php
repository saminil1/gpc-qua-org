<!DOCTYPE html>
<html>
<head>
     <meta charset="utf-8">
</head>
<body>
  <h1>JavaScript</h1>
  <script charset="utf-8">
    document.write(2==1);
  </script>
  <h1>php</h1>
  <?php
    var_dump(2==1);
  ?>
</body>
</html>
