<!DOCTYPE html>
<html>
<head>
     <meta charset="utf-8">
</head>
<body>
  <h1>php</h1>
  <?php
    echo 10+10;
  ?>
  <h1>JavaScript</h1>
  <script>
    document.write(10+10);
  </script>
</body>
</html>
