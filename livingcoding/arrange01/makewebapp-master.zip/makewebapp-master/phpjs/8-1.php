<!DOCTYPE html>
<html>
<head>
     <meta charset="utf-8">
</head>
<body>
  <form action="8-2.php">
      <p>비밀번호를 입력해주세요.</p>
      <input type="text" name="password">
      <input type="submit">
  </form>
</body>
</html>
