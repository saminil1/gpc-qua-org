<?php
echo $_GET['name'].",".$_GET['id'];
?>
